CS 254: Assignment 3

Team Members:
1. Devansh Jain  (190100044)
2. Harshit Varma (190100055)

File Descriptions:

In all questions, we used ROBDDs to design the given circuit using 2x1 MUXes.

Q1:
    TwoByOneMux.vhd     : 2x1 MUX using structural modelling
    FourByTwoEncode.vhd : 4x2 Encoder made using only 2x1 MUXes
    waveform.jpg        : Screenshot of the simulation results

Q2:
    TwoByOneMux.vhd     : 2x1 MUX using structural modelling
    TwoByFourDecode.vhd : 2x4 Decoder made using only 2x1 MUXes
    waveform.jpg        : Screenshot of the simulation results

Q3:
    TwoByOneMux.vhd     : 2x1 MUX using structural modelling
    OnebitHalfAdd.vhd   : One bit half adder made using only 2x1 MUXes
    waveform.jpg        : Screenshot of the simulation results

Q4:
    TwoByOneMux.vhd     : 2x1 MUX using structural modelling
    OnebitFullAdd.vhd   : One bit full adder made using only 2x1 MUXes
    waveform.jpg        : Screenshot of the simulation results

